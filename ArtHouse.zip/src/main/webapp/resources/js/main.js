/* 메인 자바스크립트 */

//이미지 슬라이드
$(document).ready(function(){
  $('.slider').slider();
});